﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExamYusupov.Pagas
{
    /// <summary>
    /// Логика взаимодействия для PageAvtorization.xaml
    /// </summary>
    public partial class PageAvtorization : Page
    {
        public PageAvtorization()
        {
            InitializeComponent();
        }

        private void BEnter_Click(object sender, RoutedEventArgs e)
        {
            var user = App.DB.Staffer.FirstOrDefault(x => x.Login == TBLogin.Text && x.Password == TBPassword.Password);
            if (user == null)
            {
                MessageBox.Show("Неправельный логин или пароль");
                return;
            }
            else if (user.IDRole == 1)
            {
                NavigationService.Navigate(new AdminPage());
            }
            else if (user.IDRole == 2)
            {
                NavigationService.Navigate(new StafferPage());
            }
        }
    }
}
